import React, { useState } from 'react';
import BlockList from './BlockList';
import BlockDetail from './BlockDetail';

const App = () => {
  const [selectedBlock, setSelectedBlock] = useState(null);

  const handleBlockClick = (block) => {
    setSelectedBlock(block);
  };

  return (
    <div>
      <h1>Block Explorer</h1>
      <BlockList onBlockClick={handleBlockClick} />
      {selectedBlock && <BlockDetail block={selectedBlock} />}
    </div>
  );
};

export default App;
