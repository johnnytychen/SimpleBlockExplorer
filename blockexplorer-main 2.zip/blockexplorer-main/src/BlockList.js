import React, { useEffect, useState } from 'react';
import { createAlchemyWeb3 } from '@alch/alchemy-web3';
import ethereumIcon from './ethereum.png'; // Assuming ethereum.png is in the same directory as this component

const BlockList = ({ onBlockClick }) => {
  const [blocks, setBlocks] = useState([]);

  useEffect(() => {
    const web3 = createAlchemyWeb3('https://eth-mainnet.alchemyapi.io/v2/XnCMLKtliFdOE4sBIGM_LN7O-p9s1xag');

    web3.eth.getBlockNumber()
      .then((latestBlockNumber) => {
        const blockNumbers = Array.from({ length: 10 }, (_, index) => latestBlockNumber - index);

        Promise.all(blockNumbers.map((blockNumber) => web3.eth.getBlock(blockNumber)))
          .then((blockData) => {
            setBlocks(blockData);
          })
          .catch((error) => {
            console.log('Error fetching blocks:', error);
          });
      })
      .catch((error) => {
        console.log('Error fetching latest block number:', error);
      });

    const getOutboundTransfers = () => {
      // Implement your logic for fetching outbound transfers using Web3
    };

    const getOwnedNFTs = () => {
      // Implement your logic for fetching owned NFTs using Web3
    };

    const listenToPendingTransactions = () => {
      // Implement your logic for listening to pending transactions using Web3
    };

    // Call the Web3 operations
    getOutboundTransfers();
    getOwnedNFTs();
    listenToPendingTransactions();
  }, []);

  return (
    <div className="ethereum-blue-container">
      <div className="ethereum-icon-container">
        <div className="ethereum-icon"></div>
      </div>

      <div className="block-list-container">
        <h2>Block List</h2>
        <ul>
          {blocks.map((block) => (
            <li key={block.number} onClick={() => onBlockClick(block)}>
              Block {block.number}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default BlockList;
