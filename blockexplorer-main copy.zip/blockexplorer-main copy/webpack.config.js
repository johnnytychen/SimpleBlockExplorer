const path = require('path');
const nodeExternals = require('webpack-node-externals');

module.exports = {
  // ... other configuration options

  target: 'node', // Set target to 'node' to indicate a Node.js environment

  externalsPresets: { node: true }, // Enable Node.js externals

  externals: [nodeExternals()], // Exclude node_modules from bundling, including 'stream'

  // ... other configuration options

  resolve: {
    fallback: {
      // Remove the fallback for the 'stream' module
    },
  },

  module: {
    rules: [
      // ... rules for handling different file types
    ],
  },

  plugins: [
    // ... plugins configuration
  ],

  // ... other configuration options

  devServer: {
    // ... dev server configuration
  },
};
