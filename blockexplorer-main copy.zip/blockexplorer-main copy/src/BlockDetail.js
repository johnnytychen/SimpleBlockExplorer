import React from 'react';

const BlockDetail = ({ block }) => {
  const timestamp = new Date(block.timestamp * 1000).toLocaleString('en-GB');

  return (
    <div>
      <h2>Block {block.id} Details</h2>
      <p>Timestamp: {timestamp}</p>
      <p>Transactions: {block.transactions.length}</p>
      <p>Hash: {block.hash}</p>
      <p>Parent Hash: {block.parentHash}</p>
      <p>Miner: {block.miner}</p>
      <p>Difficulty: {block.difficulty}</p>
      <p>Gas Used: {block.gasUsed}</p>
      {/* Include any other desired block details */}
    </div>
  );
};

export default BlockDetail;
